"""
FantasyProsRankingLocalFileSourceAdapter
==========================================

Reads a FantasyPros "Expert Consensus Rankings" export (.csv, the
format observed 2026-09-11: a two-line title header, blank line,
then `Rank,Player Name,Team,Position,ECR,vs. ECR`) and emits
RANKING-type NormalizedObservation records.

Scope note — CORRECTED 2026-09-11: this file is part of The
Athletic's weekly bundle, the same way the Athletic's projections are
Rotowire-licensed data surfaced through the Athletic (per the FAQ:
"the player point projections come from a licensed API via
Rotowire"). FantasyPros here plays the equivalent role for rankings.
This is NOT a fourth, separately-scoped source — it falls under the
2026-09-11 Athletic file-based-ingestion greenlight already recorded
in source-roadmap-status.md, same as the projections file. The
`source` field is set to "athletic" accordingly (not "fantasypros"),
with the underlying data-provider attribution ("fantasypros")
preserved in `raw_stats["provider"]` — exactly the same
provider-vs-surfacing-source split already applied to Rotowire.

Remaining scope note, unchanged: this is a **preseason/draft
consensus ranking**, not a weekly one — no week column, no opponent
column, unlike the Athletic weekly projections file. Stored as
week_number=0, the same convention ESPN's own scoringPeriodId=0 uses
for season-level entries.

The only position present in the captured file is QB (32 rows) —
this parser doesn't assume anything about how a multi-position
FantasyPros/Athletic export would be laid out, since one hasn't been
seen.
"""

from __future__ import annotations

import csv

from athletic_local_file_adapter import (
    DataType,
    NormalizedObservation,
    PlayerIdentity,
    Position,
    RankingType,
    SourceAdapter,
)
from player_key import make_player_key


class FantasyProsFormatError(Exception):
    """Genuine anomaly: header row doesn't match the expected shape."""


class FantasyProsRankingLocalFileSourceAdapter(SourceAdapter):
    # Surfacing source is "athletic" (this file is part of the Athletic
    # bundle) — the underlying data provider (FantasyPros) is recorded
    # per-observation in raw_stats["provider"], not in `source`, so
    # storage groups it with the rest of the Athletic ingestion instead
    # of treating it as an unrelated fourth source.
    source_name = "athletic"
    provider_name = "fantasypros"

    def __init__(self, file_path: str):
        self.file_path = file_path

    def fetch(self, season_id: int, week_number: int = 0) -> list[NormalizedObservation]:
        with open(self.file_path, newline="", encoding="utf-8-sig") as f:
            lines = [line.rstrip("\n") for line in f]

        header_idx = next((i for i, l in enumerate(lines) if l.startswith("Rank,")), None)
        if header_idx is None:
            raise FantasyProsFormatError("No 'Rank,...' header row found in file")

        header = [h.strip() for h in lines[header_idx].split(",")]
        expected = ["Rank", "Player Name", "Team", "Position", "ECR", "vs. ECR"]
        if header[:len(expected)] != expected:
            raise FantasyProsFormatError(f"Header mismatch: expected {expected}, got {header}")

        reader = csv.reader(lines[header_idx + 1:])
        observations: list[NormalizedObservation] = []
        for row in reader:
            if not row or not row[0].strip():
                continue
            rank_str, name, team, position_str, ecr, vs_ecr = (row + [""] * 6)[:6]
            try:
                position = Position[position_str.strip().upper()]
            except KeyError:
                raise FantasyProsFormatError(
                    f"Unrecognized position {position_str!r} for {name} — "
                    "this parser has only ever seen QB rows; a new position "
                    "value needs a human to confirm it before being silently mapped."
                )
            rank = float(rank_str)

            observations.append(NormalizedObservation(
                source=self.source_name,
                season_id=season_id,
                week_number=0,
                data_type=DataType.RANKING,
                ranking_type=RankingType[position.value],
                source_player_id=make_player_key(name, team),
                player=PlayerIdentity(name=name.strip(), team=team.strip(), position=position),
                value=rank,
                scoring_format="",  # ECR is a consensus draft rank, not scoring-format-scoped
                raw_stats={"ecr": ecr.strip(), "vs_ecr": vs_ecr.strip(), "provider": self.provider_name},
            ))
        return observations


if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else "FantasyPros-expert-rankings.csv"
    adapter = FantasyProsRankingLocalFileSourceAdapter(path)
    obs = adapter.fetch(season_id=2026)
    print(f"Parsed {len(obs)} rankings (source={adapter.source_name}, provider={adapter.provider_name})")
    for o in obs[:3]:
        print(o)
