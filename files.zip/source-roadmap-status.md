# Multi-Source Roadmap — Status (as of 2026-09-11)

Backend v1 (data model, storage, ingestion, ESPN adapter) is frozen — see `phase-4c-status.md`. This doc tracks the decision, not yet implementation, for which sources become Source #2 and #3, and why.

## Why three specific sources

The project's target sources are **ESPN, Yahoo, and The Athletic** — chosen because they're the major fantasy-football information sources people actually use, not because they're the easiest to access. A technically-easier but obscure public source (e.g. Sleeper) was explicitly considered and rejected as a *substitute* for this reason. Adding any other source (e.g. Footballguys, or Rotowire — see The Athletic findings below) is a deliberate scope decision, not a byproduct of validating the existing three.

## 2026-09-11 update: Week 1 source capture (Yahoo) + The Athletic greenlit

**Yahoo — Week 1 capture logged, still DEFERRED overall.** A screenshot of Yahoo Sports' public "Fantasy Football Rankings Week 1 (Full PPR)" article (dated 2026-09-11, in-season) was captured. Two things worth separating:
- This is a **different Yahoo surface** than either previously-tested one: not the authenticated in-league app (which showed real per-player point projections), and not the earlier logged-out "Top-300 draft article" (preseason, ranks only). This is a **public, no-login, in-season** consensus-rank article — 214 ranked players, opponent shown, explicitly "Data compiled by FantasyPros," not Yahoo's own model.
- This narrows one open item (a public/no-auth path to *some* Yahoo-branded weekly content exists) but does **not** resolve programmatic access, PPR-equivalence for the in-app numbers, or ToS/automation — those remain OPEN. It also carries rank order only, no point values, so it doesn't substitute for the in-app projection data already found. **Yahoo adapter: still NOT AUTHORIZED**, per standing rule, until explicitly greenlit.

**The Athletic — GREENLIT for a file-based adapter (2026-09-11), reversing the 2026-09-05 call.** The prior "not greenlit even with an access path resolved" conclusion was specifically about the *named-player-lookup, max-5/query* access shape making automation heavier than ESPN/Yahoo's bulk fetch — that was the actual blocker, not the projections themselves. New fact: a **weekly downloadable export** (`Week1Proj0910.xlsx`, Week 1 2026, Half-PPR, QB/RB/WR/TE, 232 players, Rotowire-shaped stat categories matching the documented Fantasy Concierge output) is now available directly, which removes the per-query-limit problem entirely — this is a bulk file, not a scraped 5-at-a-time lookup. That changed fact is what justifies reopening the decision; the automation-shape concern that blocked it originally no longer applies to this access method.

Still disclosed, not swept under the rug:
- **Not a bulk API** — this is a manually-obtained weekly file, not an automated pull. Automation/ToS for *how the file itself is obtained* each week is still unassessed and is a separate question from "can we parse the file once we have it."
- **Scoring format is Half-PPR**, not PPR — recorded honestly as `HALF_PPR`, coexisting with (not overwriting) PPR rows, per the storage layer's existing `scoring_format`-in-uniqueness-key design.
- **No stable cross-source player ID** — the file has Name/Team only. A `name|team` normalized string is used as `source_player_id`; this is not guaranteed to join cleanly against ESPN's numeric IDs without a reconciliation step, which does not exist yet.
- **Projections only, no rankings and no actuals** in this file — "we have weekly downloads of their rankings and projections" is the stated expectation, but only a projections file has been seen and parsed so far. If a separate weekly rankings export exists, it needs its own file and its own parser; nothing should be assumed about its shape until one is captured.
- **One week's file only** — the parser validates the header shape on every load and fails loudly (`AthleticFormatError`) rather than silently misreading columns if a future week's export is laid out differently, but a second week has not yet been used to confirm the layout is stable.

**Adapter delivered (pending real integration):** `athletic_local_file_adapter.py` — a `SourceAdapter`-shaped file reader modeled on the existing ESPN `LocalFileSourceAdapter` pattern, parsed and verified against the actual uploaded file (232/232 rows parsed, counts matching the file exactly: 32 QB / 75 RB / 95 WR / 30 TE). Built against the *documented* contract only, since the real `normalized.py`/`storage.py` were not available in this session — needs reconciliation against the real modules before merging, same caveat as every other standalone-adapter delivery in this project.

**Correction (2026-09-11, same day):** the FantasyPros consensus-ranking CSV originally treated below as a separate, out-of-scope "ancillary ingest" is actually **part of the Athletic's weekly bundle**, not an independent fourth source — the same relationship the Athletic's projections already have with Rotowire (Rotowire supplies the projection numbers, the Athletic surfaces them; FantasyPros supplies these rankings, the Athletic surfaces them). Fixed: `fantasypros_local_file_adapter.py`'s `FantasyProsRankingLocalFileSourceAdapter` now emits `source="athletic"` with `raw_stats["provider"]="fantasypros"` for attribution, instead of `source="fantasypros"` — so it groups with the rest of the Athletic ingestion under the existing 2026-09-11 greenlight rather than needing its own scope decision. No new source was added; this is two file types (projections + rankings) under one already-decided source.

Verified: name+team matching (via the new shared `player_key.py` — suffix/punctuation/accent stripping plus a team-alias table) joined all 32 QBs between the projections file and the rankings file with zero misses, confirming this is a workable cross-file join key for what's been captured so far.

## Revised interpretation of criterion #3 (2026-09-05)

Criterion #3 ("weekly projections available") was initially being tested against **preseason** evidence — but weekly projections are inherently time-dependent: a source can't be expected to expose Week 5 projections in September, since that data doesn't exist yet and shouldn't.

**Revised criterion #3: does the source provide a recurring weekly projection/ranking mechanism that can be captured once that week's data is actually published** — not "is it already available today."

**Backend v1 already supports this correctly — no data model or schema change needed.** The `NormalizedObservation` contract (`source, season_id, week_number, data_type, ...`) was built exactly as a source → player → week → observation-type snapshot. `DataType.PROJECTION` and `DataType.ACTUAL` already coexist per week without overwriting each other, and storage's uniqueness key already includes `week_number`.

## Three-source summary

| Source | Weekly projections | Weekly actuals | Access mechanism | Status |
|---|---|---|---|---|
| ESPN | Proven | Proven | Public, unauthenticated endpoint | **FROZEN (v1)** |
| Yahoo | Proven (in-app) | API mechanism documented; live 2026 capture pending | Authenticated web app (confirmed) / OAuth API (documented, unused) / public no-login consensus-rank article (new, ranks only, 2026-09-11) | **DEFERRED** |
| The Athletic | Proven (Fantasy Concierge / weekly file export) | Open | Weekly downloadable export (file-based) | **GREENLIT — file-based adapter only, 2026-09-11** |

No backend work is required to accommodate any of these — the existing `Projection`/`Actual` + week-based observation model already fits.

## Yahoo — status breakdown (2026-09-05, unchanged 2026-09-11)

- **Data mechanism: PROVEN.** The authenticated in-league web app has a real "Week 1 (proj)" view, populated with real per-player projected points and underlying raw stat categories, four days before Week 1 games — see "Yahoo — authenticated in-app findings" below.
- **PPR scoring equivalence: OPEN.** The "Fan Pts" values observed reflect that specific league's own configured scoring rules — not yet confirmed to be PPR.
- **Programmatic access: OPEN.** The web app's internal request mechanism has not been investigated (deliberately, to avoid touching session-authenticated traffic). The documented OAuth API has no projections endpoint at all. The 2026-09-11 public article is a rank-order-only surface and doesn't change this.
- **Automation/ToS: OPEN.** Not assessed — moot until an access path exists.
- **Actuals:** documented OAuth API mechanism exists; live 2026 capture pending.
- **Adapter: NOT AUTHORIZED.** No code until explicitly greenlit.

## Yahoo — authenticated in-app findings (2026-09-05)

The project owner signed into their own real Yahoo Fantasy Football league (their own credentials, their own session — not handled or seen by Claude) and shared the resulting browser view. Observed directly (read-only page text, no network/cookie inspection performed):

- The league's **Players → Player List** page has a "Stats" view selector: **Week 1 (proj)**, Week 2 (proj), Week 3 (proj), Next 4 Weeks (proj), Season (proj), Remaining Games (proj), Week 1 (post-game actual), Season/2025/2024 (total), plus Splits/Ranks/Research/Matchups views.
- With "Week 1 (proj)" selected: Daniel Jones (Ind QB) 16.14, C.J. Stroud (Hou QB) 14.62, Cam Ward (Ten QB) 14.64, Malik Willis (Mia QB) 15.54, Baker Mayfield (TB QB) 15.17, each with real Week 1 opponent/kickoff shown. Zach Charbonnet (PUP) correctly showed 0.00 — not fabricated.
- Each row also carries underlying raw projected stats, same shape as ESPN's category breakdown.
- No credentials, tokens, or cookies were seen, requested, or handled by Claude in this check.

## Yahoo — public documentation and logged-out site findings

- **Documented API:** base endpoint `https://fantasysports.yahooapis.com/fantasy/v2`; `player_key` = `{game_key}.p.{player_id}` (Yahoo's own numbering — cross-source joins go on name/team/position); `/player/{player_key}/stats` documented with season/week/date coverage, OAuth-gated. Zero mentions of "projection"/"projected" anywhere in the reference. OAuth 2.0 required on every request. Attribution required: "Fantasy data provided by Yahoo Fantasy."
- **Logged-out consumer site (2026-09-05):** a static "Top-300 for 2026 drafts" consensus-rank article (ranks only, no points, no weekly dimension).
- **Logged-out consumer site, in-season (2026-09-11, new):** a second public article, "Fantasy Football Rankings Week 1 (Full PPR)," with real in-season weekly rank order for 214 players — attributed to FantasyPros, not Yahoo's own model. Confirms Yahoo's public site does carry *some* real in-season weekly content without login, but still rank-order only, no raw points — doesn't supersede or unlock the authenticated in-app projection numbers.

## The Athletic — status breakdown (2026-09-05, revised 2026-09-11)

- **Mechanism: PROVEN**, now via two independent paths: Fantasy Concierge (described in the Athletic's own FAQ) and a **weekly downloadable export** confirmed 2026-09-11 (`Week1Proj0910.xlsx`).
- **Weekly PPR projections: PROVEN** — the FAQ confirms PPR/Half-PPR/Standard are explicitly selectable; the captured file is Half-PPR.
- **Projection origin:** Rotowire licensed data, not Athletic-generated — "the player point projections come from a licensed API via Rotowire," per the FAQ verbatim. An adapter here attributes Rotowire-originated numbers, not the Athletic's own modeling.
- **Ciely component:** rankings/analysis layered on top of the Rotowire projection is a separate signal from the raw projection number and is NOT part of what's been captured or parsed so far.
- **Population shape — REVISED 2026-09-11.** Previously assessed as "named-player lookup, max 5 players per query — not a bulk feed," which was the actual reason the adapter stayed not-greenlit. The weekly file export is a full bulk snapshot (232 players across QB/RB/WR/TE in one file) — this access shape does not have the per-query limitation and is comparable in automation profile to a captured-fixture read (like the ESPN `LocalFileSourceAdapter`), not to the constrained live-lookup tool.
- **Concrete runtime output: NOW CAPTURED.** `Week1Proj0910.xlsx`, Week 1 2026, parsed and verified (232/232 rows, exact per-position counts matching the source file).
- **Programmatic access to the live tool itself: still UNKNOWN** — this greenlight covers ingesting a weekly file someone already has, not scraping `athletic-fantasy-concierge.nytimes.com`, which remains hard-blocked by policy in every tool available in this environment, unchanged from 2026-09-05.
- **Automation/ToS for obtaining the file itself: UNKNOWN**, and explicitly out of scope for this greenlight — this decision only covers "parse a file once you have it," not "how the file is obtained weekly, automatically."
- **Actuals:** still need live validation; the captured file has no actuals column.
- **Adapter: GREENLIT for file-based ingestion only** (`athletic_local_file_adapter.py`, delivered 2026-09-11). Live-scrape/API access remains NOT GREENLIT and is a separate, unaddressed question.

## Candidate #4: Footballguys (unresearched, 2026-09-05)

Not part of the project's original three-source scope and not added to it. The project owner reported (from separate work, not independently verified by Claude): a public 2026 projections section; PPR scoring support; a dedicated Week 1 projections page; some projection depth subscription-gated. Not established: weekly actuals, historical availability, a usable structured endpoint, reproducible subscriber access, or automation/ToS acceptability.

**Status: unresearched candidate, not a validated source.** Same for a potential **Rotowire** candidate, newly surfaced by the Fantasy Concierge findings above — also unresearched, also not part of scope, also would need its own from-scratch evidence gathering if ever pursued. Note: Rotowire is now indirectly in the pipeline as the Athletic's data supplier, not as its own adapter — that distinction should stay explicit in any output/UI that surfaces this data (attribute to Rotowire-via-Athletic, not to the Athletic's own analysis).

## Next major milestone: Week 1 actuals capture

NFL 2026 Week 1 games are underway. Once Week 1 results are final, capture ESPN's actuals (proven mechanism) and, if a weekly Athletic actuals file materializes, add it to the same pipeline — actuals were never part of the file captured so far.

## 8-point standard used to evaluate a candidate source

1. Publicly accessible
2. No credentials required for research/validation
3. Weekly projections available **during the NFL season, once that week's data is published** (revised 2026-09-05)
4. Weekly actuals available
5. Player identity can be normalized reliably
6. PPR-relevant data can be established
7. Live 2025/2026 data can prove the mechanism
8. Terms/access method don't create an unacceptable automation problem

## Standing rules while this is open

- No adapter code for Yahoo, Sleeper, or any other undecided candidate until the project owner explicitly greenlights that specific source. (The Athletic's file-based path is now the one exception, scoped exactly as described above — this does not extend to Athletic live-scrape/API access, which is still ungreenlit.)
- Claude never handles GitHub tokens, OAuth credentials, session cookies, or any other API key/token/secret directly, for any source — hard rule, not a technical gap. Read-only observation of a page the project owner has already authenticated themselves is within that rule; inspecting network requests, cookies, or session tokens is not, and hasn't been done. Claude has no accounts or credentials of its own for any source, ever — including The Athletic; `theathletic.com` and its `athletic-fantasy-concierge.nytimes.com` iframe subdomain are additionally hard-blocked by policy in every tool available in this environment (browser pane and fetch), confirmed on retry 2026-09-05, independent of any credential question.
- Evidence the project owner gathers from an authenticated/blocked source is handed over with credentials already redacted by them before Claude sees it.
- A new candidate source (e.g. Footballguys, Rotowire-as-its-own-adapter) requires a deliberate scope decision plus its own from-scratch evidence gathering before being added to the target list.
